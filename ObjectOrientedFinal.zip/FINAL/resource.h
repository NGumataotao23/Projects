//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Final.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FINAL_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     131
#define IDB_BITMAP2                     132
#define IDB_BITMAP3                     133
#define IDB_BITMAP4                     134
#define IDB_BITMAP5                     135
#define IDB_BITMAP6                     136
#define IDB_BITMAP7                     137
#define IDB_BITMAP8                     138
#define IDB_BITMAP9                     139
#define IDB_BITMAP10                    141
#define IDB_BITMAP11                    142
#define IDB_BITMAP12                    143
#define IDB_BITMAP13                    144
#define IDB_BITMAP14                    145
#define IDB_BITMAP15                    146
#define IDB_BITMAP16                    147
#define IDB_BITMAP17                    148
#define IDC_COMBO1                      1000
#define IDC_BUTTON1                     1001
#define IDC_CHECK1                      1002
#define IDC_EDIT1                       1003
#define IDC_EDIT2                       1005
#define IDC_BUTTON2                     1006
#define IDC_EDIT3                       1007
#define IDC_STATIC2                     1013
#define IDC_EDIT4                       1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
